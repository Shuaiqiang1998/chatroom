#ifndef CHATROOM_CLIENT_H
#define CHATROOM_CLIENT_H

#include <string>
#include "Common.h"
#include <mysql/mysql.h>

using namespace std;

class Client
{
public:
	Client();
	void Connect();
	void Close();
	void Start();
    int log();//登陆功能，查询数据库是否存在此用户，不存在就不允许使用
    int FindMysql(int logNum,string password);//查询数据库
    void regUser();//注册功能

private:
	int sock;
	int pid;
	int epfd;
	int pipe_fd[2];
	bool isClientWork;
    int logNum;
    string password;

	Msg msg;
	char send_buf[BUF_SIZE];
	char recv_buf[BUF_SIZE]={'a','b','c'};

	struct sockaddr_in serverAddr;
};

#endif
