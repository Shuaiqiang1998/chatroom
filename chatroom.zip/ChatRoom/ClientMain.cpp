#include "Client.h"

int main(int argc, char const *argv[])
{
	Client client;
	client.Start();
	return 0;
}