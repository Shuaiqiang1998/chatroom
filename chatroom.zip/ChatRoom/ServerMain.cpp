#include "Server.h"

int main(int argc, char const *argv[])
{
	Server server;
	server.Start();
	return 0;
}